(function () {
  "use strict";

  var I18N = {
    en: {
      brandTag: "hotel guest wi-fi",
      eyebrow: "Hotel guest Wi-Fi",
      headline: "Welcome.<br>Let’s get you online.",
      intro: "Use the email address from your booking and the Wi-Fi password from reception.",
      help: "Need help? Call reception.",
      formTitle: "Sign in",
      formSub: "Enter your guest email and Wi-Fi password.",
      email: "Email address",
      password: "Password",
      show: "Show",
      hide: "Hide",
      connect: "Connect",
      terms: "By connecting, you agree to the hotel’s acceptable-use policy.",
      successTitle: "You’re connected",
      successText: "Taking you online…",
      continue: "Continue browsing",
      foot: "Secure guest access · Hotel front desk",
      error: "That email and password did not match. Check with reception.",
      invalidEmail: "Enter a valid email address.",
      network: "We couldn’t reach the Wi-Fi service. Try again.",
      busy: "Connecting…"
    },
    ar: {
      brandTag: "واي فاي للنزلاء",
      eyebrow: "واي فاي النزلاء",
      headline: "أهلاً بك.<br>لنوصلك بالإنترنت.",
      intro: "استخدم البريد الإلكتروني الموجود في حجزك وكلمة مرور الواي فاي من الاستقبال.",
      help: "تحتاج مساعدة؟ اتصل بالاستقبال.",
      formTitle: "تسجيل الدخول",
      formSub: "أدخل بريدك الإلكتروني وكلمة مرور الواي فاي.",
      email: "البريد الإلكتروني",
      password: "كلمة المرور",
      show: "إظهار",
      hide: "إخفاء",
      connect: "اتصال",
      terms: "بالاتصال، فإنك توافق على سياسة الاستخدام المقبول في الفندق.",
      successTitle: "تم الاتصال",
      successText: "جارٍ توصيلك بالإنترنت…",
      continue: "متابعة التصفح",
      foot: "دخول آمن للنزلاء · مكتب الاستقبال",
      error: "البريد الإلكتروني أو كلمة المرور غير صحيحة. تحقق مع الاستقبال.",
      invalidEmail: "أدخل بريدًا إلكترونيًا صحيحًا.",
      network: "تعذر الوصول إلى خدمة الواي فاي. حاول مرة أخرى.",
      busy: "جارٍ الاتصال…"
    },
    fr: {
      brandTag: "wi-fi clients",
      eyebrow: "Wi-Fi clients",
      headline: "Bienvenue.<br>Connectons-vous.",
      intro: "Utilisez l’adresse e-mail de votre réservation et le mot de passe Wi-Fi remis à la réception.",
      help: "Besoin d’aide ? Appelez la réception.",
      formTitle: "Connexion",
      formSub: "Saisissez votre e-mail client et votre mot de passe Wi-Fi.",
      email: "Adresse e-mail",
      password: "Mot de passe",
      show: "Afficher",
      hide: "Masquer",
      connect: "Se connecter",
      terms: "En vous connectant, vous acceptez la politique d’usage acceptable de l’hôtel.",
      successTitle: "Vous êtes connecté",
      successText: "Mise en ligne en cours…",
      continue: "Continuer la navigation",
      foot: "Accès client sécurisé · Réception",
      error: "L’e-mail et le mot de passe ne correspondent pas. Vérifiez avec la réception.",
      invalidEmail: "Saisissez une adresse e-mail valide.",
      network: "Impossible de joindre le service Wi-Fi. Réessayez.",
      busy: "Connexion…"
    }
  };

  var form = document.getElementById("login-form");
  var email = document.getElementById("email");
  var password = document.getElementById("password");
  var toggle = document.getElementById("toggle-password");
  var submit = document.getElementById("submit");
  var alertBox = document.getElementById("alert");
  var success = document.getElementById("success");
  var continueLink = document.getElementById("continue");
  var langButtons = Array.prototype.slice.call(document.querySelectorAll("[data-lang]"));

  var params = new URLSearchParams(window.location.search);
  var stored = null;
  try { stored = window.localStorage.getItem("portalLang"); } catch (e) {}
  var initial = params.get("lang") || stored;
  if (!initial) {
    var nav = (navigator.language || "en").toLowerCase();
    initial = nav.indexOf("ar") === 0 ? "ar" : nav.indexOf("fr") === 0 ? "fr" : "en";
  }
  var lang = I18N[initial] ? initial : "en";

  function t(key) {
    return (I18N[lang] && I18N[lang][key]) || I18N.en[key] || key;
  }

  function applyLang(next) {
    lang = I18N[next] ? next : "en";
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
    document.querySelectorAll("[data-i18n]").forEach(function (el) {
      el.textContent = t(el.getAttribute("data-i18n"));
    });
    document.querySelectorAll("[data-i18n-html]").forEach(function (el) {
      el.innerHTML = t(el.getAttribute("data-i18n-html"));
    });
    langButtons.forEach(function (button) {
      button.setAttribute("aria-pressed", button.getAttribute("data-lang") === lang ? "true" : "false");
    });
    toggle.textContent = password.type === "password" ? t("show") : t("hide");
    try { window.localStorage.setItem("portalLang", lang); } catch (e) {}
  }

  function showError(message) {
    alertBox.textContent = message;
    alertBox.hidden = false;
  }

  function clearError() {
    alertBox.hidden = true;
    alertBox.textContent = "";
  }

  function setBusy(busy) {
    submit.disabled = busy;
    submit.querySelector("span").textContent = busy ? t("busy") : t("connect");
  }

  function safeRedirect() {
    var raw = params.get("redirurl") || "";
    if (!raw) return "";
    try {
      var url = new URL(raw.indexOf("://") === -1 ? "http://" + raw : raw);
      return url.protocol === "http:" || url.protocol === "https:" ? url.href : "";
    } catch (e) {
      return "";
    }
  }

  function showSuccess() {
    form.hidden = true;
    success.hidden = false;
    var target = safeRedirect();
    continueLink.href = target || "/";
    if (target) {
      window.setTimeout(function () { window.location.href = target; }, 900);
    }
  }

  function checkStatus() {
    if (!window.fetch) return;
    fetch("/api/captiveportal/access/status/0/", { cache: "no-store" })
      .then(function (response) { return response.ok ? response.json() : null; })
      .then(function (data) {
        if (data && data.clientState === "AUTHORIZED") showSuccess();
      })
      .catch(function () {});
  }

  toggle.addEventListener("click", function () {
    var visible = password.type === "text";
    password.type = visible ? "password" : "text";
    toggle.setAttribute("aria-pressed", visible ? "false" : "true");
    toggle.textContent = visible ? t("show") : t("hide");
    password.focus();
  });

  langButtons.forEach(function (button) {
    button.addEventListener("click", function () {
      applyLang(button.getAttribute("data-lang"));
    });
  });

  form.addEventListener("submit", function (event) {
    event.preventDefault();
    clearError();

    var value = email.value.trim();
    if (!email.checkValidity() || value.indexOf("@") < 1) {
      showError(t("invalidEmail"));
      email.focus();
      return;
    }
    if (!password.value) {
      showError(t("error"));
      password.focus();
      return;
    }

    setBusy(true);
    fetch("/api/captiveportal/access/logon/", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8" },
      body: new URLSearchParams({ user: value, password: password.value })
    })
      .then(function (response) { return response.json(); })
      .then(function (data) {
        if (data && data.clientState === "AUTHORIZED") {
          showSuccess();
        } else {
          showError(t("error"));
          setBusy(false);
        }
      })
      .catch(function () {
        showError(t("network"));
        setBusy(false);
      });
  });

  applyLang(lang);
  checkStatus();
})();
